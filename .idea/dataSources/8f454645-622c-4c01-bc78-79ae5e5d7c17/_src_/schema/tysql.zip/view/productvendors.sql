CREATE VIEW tysql.productvendors AS
  SELECT
    `tysql`.`vendors`.`vend_name`     AS `vend_name`,
    `tysql`.`vendors`.`vend_address`  AS `vend_address`,
    `tysql`.`products`.`prod_name`    AS `prod_name`,
    `tysql`.`orderitems`.`item_price` AS `item_price`,
    `tysql`.`orderitems`.`order_num`  AS `order_num`
  FROM `tysql`.`vendors`
    JOIN `tysql`.`products`
    JOIN `tysql`.`orderitems`
  WHERE ((`tysql`.`vendors`.`vend_id` = `tysql`.`products`.`vend_id`) AND
         (`tysql`.`orderitems`.`prod_id` = `tysql`.`products`.`prod_id`));
