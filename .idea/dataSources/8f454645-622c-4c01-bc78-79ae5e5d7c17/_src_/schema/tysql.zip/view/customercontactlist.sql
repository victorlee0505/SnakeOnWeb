CREATE VIEW tysql.customercontactlist AS
  SELECT concat(`tysql`.`customers`.`cust_name`, '(', `tysql`.`customers`.`cust_contact`, ')') AS `cust_address_list`
  FROM `tysql`.`customers`;
