CREATE VIEW tysql.productcustomers AS
  SELECT
    `tysql`.`customers`.`cust_name`    AS `cust_name`,
    `tysql`.`customers`.`cust_contact` AS `cust_contact`,
    `tysql`.`orderitems`.`prod_id`     AS `prod_id`
  FROM `tysql`.`customers`
    JOIN `tysql`.`orders`
    JOIN `tysql`.`orderitems`
  WHERE ((`tysql`.`orders`.`cust_id` = `tysql`.`customers`.`cust_id`) AND
         (`tysql`.`orderitems`.`order_num` = `tysql`.`orders`.`order_num`));
