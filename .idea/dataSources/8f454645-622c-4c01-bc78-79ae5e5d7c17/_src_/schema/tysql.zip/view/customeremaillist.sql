CREATE VIEW tysql.customeremaillist AS
  SELECT concat(`tysql`.`customers`.`cust_name`, '(', `tysql`.`customers`.`cust_email`, ')') AS `cust_name_with_email`
  FROM `tysql`.`customers`
  WHERE (`tysql`.`customers`.`cust_email` IS NOT NULL);
